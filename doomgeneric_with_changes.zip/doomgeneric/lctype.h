#ifndef LCTYPE_H_   /* Include guard */
#define LCTYPE_H_

int toupper(int ch);



#endif // LCTYPE_H_