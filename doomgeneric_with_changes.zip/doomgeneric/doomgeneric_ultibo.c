#include "doomkeys.h"

#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include <stdarg.h>
#include <stdio.h>
#include <math.h>
#include <fcntl.h>
#include <sys/timeb.h>
#include <time.h>


#include "doomgeneric.h"

typedef unsigned int   DWORD;
typedef unsigned long  ULONG;
typedef unsigned char  UCHAR;
typedef unsigned short USHORT;

DWORD                start_clock_count = 0;

#ifdef __cplusplus
extern "C" {
#endif

void getMouseXY(int *cx, int *cy, int *btc);
void getScreenSize(unsigned long int *scrWidth, unsigned long int *scrHeight);

int getScreenPitch(void);
USHORT* getScreenBuffer(void);

void getKey(int *value);  

#ifdef __cplusplus
}
#endif

/*
#define KEYQUEUE_SIZE 16

static unsigned short s_KeyQueue[KEYQUEUE_SIZE];
static unsigned int s_KeyQueueWriteIndex = 0;
static unsigned int s_KeyQueueReadIndex = 0;

static unsigned char convertToDoomKey(unsigned char key)
{
	switch (key)
	{
	case VK_RETURN:
		key = KEY_ENTER;
		break;
	case VK_ESCAPE:
		key = KEY_ESCAPE;
		break;
	case VK_LEFT:
		key = KEY_LEFTARROW;
		break;
	case VK_RIGHT:
		key = KEY_RIGHTARROW;
		break;
	case VK_UP:
		key = KEY_UPARROW;
		break;
	case VK_DOWN:
		key = KEY_DOWNARROW;
		break;
	case VK_CONTROL:
		key = KEY_FIRE;
		break;
	case VK_SPACE:
		key = KEY_USE;
		break;
	case VK_SHIFT:
		key = KEY_RSHIFT;
		break;
	default:
		key = tolower(key);
		break;
	}

	return key;
}

static void addKeyToQueue(int pressed, unsigned char keyCode)
{
	unsigned char key = convertToDoomKey(keyCode);

	unsigned short keyData = (pressed << 8) | key;

	s_KeyQueue[s_KeyQueueWriteIndex] = keyData;
	s_KeyQueueWriteIndex++;
	s_KeyQueueWriteIndex %= KEYQUEUE_SIZE;
}
*/
DWORD Start_Clock(void);
int Key = -1;

unsigned long int ScreenWidth = 800;
unsigned long int ScreenHeight = 480;

//unsigned char *lvideo_buffer;
int mempitch;
UCHAR* dest_buffer;


void DG_Init()
{
  Start_Clock();
  getScreenSize(&ScreenWidth, &ScreenHeight);   
	
  mempitch = getScreenPitch();
  
  //lvideo_buffer = (unsigned char*) calloc ( (ScreenWidth * 2) * (ScreenHeight * 2 ),sizeof(unsigned char) );
  
  dest_buffer = (UCHAR*)getScreenBuffer();
  
   //memset(lvideo_buffer, 0xff , (ScreenWidth * 2) * (ScreenHeight * 2 ));
   //memcpy(lvideo_buffer,DG_ScreenBuffer, (DOOMGENERIC_RESX * 2) * (DOOMGENERIC_RESY * 2));
   //memcpy(dest_buffer,lvideo_buffer, (ScreenWidth * 2) * (ScreenHeight * 2 ));  
  
   //DG_SleepMs(5000);
}

/*
void DG_DrawFrame()
{
	MSG msg;
	memset(&msg, 0, sizeof(msg));

	while (PeekMessageA(&msg, 0, 0, 0, PM_REMOVE) > 0)
	{
		TranslateMessage(&msg);
		DispatchMessageA(&msg);
	}

	StretchDIBits(s_Hdc, 0, 0, DOOMGENERIC_RESX, DOOMGENERIC_RESY, 0, 0, DOOMGENERIC_RESX, DOOMGENERIC_RESY, DG_ScreenBuffer, &s_Bmi, 0, SRCCOPY);

	SwapBuffers(s_Hdc);
}
*/

void DG_DrawFrame()
{
   //memset(lvideo_buffer, 0xff , (ScreenWidth * 2) * (ScreenHeight * 2 ));
   //memcpy(lvideo_buffer,DG_ScreenBuffer, (DOOMGENERIC_RESX * 2) * (DOOMGENERIC_RESY * 2));
   memcpy(dest_buffer,DG_ScreenBuffer, (ScreenWidth * 2) * (ScreenHeight * 2 ));
}

DWORD Get_Clock(void)
{
// this function returns the current tick count

// return time
return(clock());//GetTickCount());

} // end Get_Clock

DWORD Start_Clock(void)
{
// this function starts the clock, that is, saves the current
// count, use in conjunction with Wait_Clock()

return(start_clock_count = Get_Clock());

} // end Start_Clock

void DG_SleepMs(uint32_t ms)
{
// this function is used to wait for a specific number of clicks
// since the call to Start_Clock

 while((Get_Clock() - start_clock_count) < ms);
//return(Get_Clock());

} // end Wait_Clock
/*
{
	Sleep(ms);
}
*/
uint32_t DG_GetTicksMs()
{
	return clock();//GetTickCount();
}

int DG_GetKey(int* pressed, unsigned char* doomKey)
{
    getKey(&Key);
	if(Key != -1) 
    { 
      if (Key != 0)
      {
		if(Key == 'f' || Key == 'F')
         *doomKey = KEY_FIRE;
        else	
		 *doomKey = Key;
	    return 1; 
	  }
	  else
	  {
		getKey(&Key);   
		 if(Key == 0x48)
		  *doomKey = KEY_UPARROW; 
         else if(Key == 0x50)
          *doomKey = KEY_DOWNARROW; 
         else if(Key == 0x4B)
          *doomKey = KEY_LEFTARROW; 
         else if(Key == 0x4D)
          *doomKey = KEY_RIGHTARROW;
         return 1; 	  
	  }
	  *doomKey = 0;
	  return 0;
    }
     
    *doomKey = 0;	
 return 0;
}

void DG_SetWindowTitle(const char * title)
{

}